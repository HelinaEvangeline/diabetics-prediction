A,001–139: infectious and parasitic diseases
B,140–239: neoplasms
C,240–279: endocrine, nutritional and metabolic diseases, and immunity disorders
D,280–289: diseases of the blood and blood-forming organs
E,290–319: mental disorders
F,320–359: diseases of the nervous system
G,360–389: diseases of the sense organs
H,390–459: diseases of the circulatory system
I,460–519: diseases of the respiratory system
J,520–579: diseases of the digestive system
K,580–629: diseases of the genitourinary system
L,630–679: complications of pregnancy, childbirth, and the puerperium
M,680–709: diseases of the skin and subcutaneous tissue
N,710–739: diseases of the musculoskeletal system and connective tissue
O,740–759: congenital anomalies
P,760–779: certain conditions originating in the perinatal period
Q,780–799: symptoms, signs, and ill-defined conditions
R,800–999: injury and poisoning
X,'E' codes – external causes of injury
Y,'V' codes – Supplementary classification of factors influencing health status and contact with health services
